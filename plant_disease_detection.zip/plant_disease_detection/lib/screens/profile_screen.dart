import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  // Mock profile data
  String firstName = "John";
  String lastName = "Doe";
  String email = "john.doe@email.com";

  bool dailyTips = true;
  String themeMode = 'Auto';
  bool notifications = true;

  final List<Map<String, String>> achievements = [
    {'title': 'First Scan', 'subtitle': 'Scanned your first plant'},
    {'title': '10 Scans', 'subtitle': '10 successful diagnoses'},
    {'title': 'Green Thumb', 'subtitle': '5 plants kept healthy'},
  ];

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.98,
      upperBound: 1.02,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _goToEditProfile() async {
    final updatedData = await Navigator.pushNamed(
      context,
      '/edit-profile',
      arguments: {
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
      },
    );

    if (updatedData is Map<String, dynamic>) {
      setState(() {
        firstName = updatedData['firstName'] ?? firstName;
        lastName = updatedData['lastName'] ?? lastName;
        email = updatedData['email'] ?? email;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully')),
      );
    }
  }

  void _showActionsSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Clear History'),
                onTap: () {
                  Navigator.pop(context);
                  _confirmClearHistory();
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Logout'),
                onTap: () {
                  Navigator.pop(context);
                  _confirmLogout();
                },
              ),
              ListTile(
                leading:
                const Icon(Icons.delete_forever, color: Colors.redAccent),
                title: const Text(
                  'Delete Account',
                  style: TextStyle(color: Colors.redAccent),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _confirmDeleteAccount();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmClearHistory() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear History'),
        content: const Text(
            'Are you sure you want to clear your history? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Clear')),
        ],
      ),
    );
    if (ok == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('History cleared')),
      );
    }
  }

  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Do you want to log out from this device?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Stay')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Logout')),
        ],
      ),
    );
    if (ok == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Logged out successfully')),
      );
    }
  }

  Future<void> _confirmDeleteAccount() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text(
            'This will permanently delete your account and data. Continue?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Account deleted')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.green.shade50,
              Colors.green.shade100,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: Colors.transparent,
              elevation: 0,
              expandedHeight: 220,
              flexibleSpace: FlexibleSpaceBar(
                background: SafeArea(
                  child: Padding(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ScaleTransition(
                          scale: _pulseController,
                          child: CircleAvatar(
                            radius: 48,
                            backgroundColor: Colors.green.shade300,
                            child: const Icon(Icons.local_florist,
                                size: 44, color: Colors.white),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "$firstName $lastName",
                                style: theme.textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Plant Enthusiast • 15 scans',
                                style: theme.textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: _goToEditProfile,
                          icon: const Icon(Icons.edit),
                          tooltip: 'Edit Profile',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // BODY
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              sliver: SliverList(
                delegate: SliverChildListDelegate(
                  [
                    // Personal Info
                    Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.person, size: 20),
                                const SizedBox(width: 8),
                                Text(
                                  'Personal Information',
                                  style: theme.textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                            const Divider(),
                            const SizedBox(height: 8),
                            Text('First Name: $firstName'),
                            Text('Last Name: $lastName'),
                            Text('Email: $email'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Preferences
                    Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      elevation: 1.5,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.settings, size: 20),
                                const SizedBox(width: 8),
                                Text('App Preferences',
                                    style: theme.textTheme.titleMedium
                                        ?.copyWith(fontWeight: FontWeight.w600)),
                              ],
                            ),
                            const SizedBox(height: 12),
                            SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              title: const Text('Daily Plant Tips'),
                              subtitle: const Text('Receive daily care tips'),
                              value: dailyTips,
                              onChanged: (v) => setState(() => dailyTips = v),
                              secondary: const Icon(Icons.lightbulb),
                            ),
                            SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              title: const Text('Notifications'),
                              subtitle: const Text('Enable push notifications'),
                              value: notifications,
                              onChanged: (v) => setState(() => notifications = v),
                              secondary: const Icon(Icons.notifications),
                            ),
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const Icon(Icons.palette),
                              title: const Text('Theme'),
                              trailing: DropdownButton<String>(
                                value: themeMode,
                                items: const [
                                  DropdownMenuItem(
                                      value: 'Light', child: Text('Light')),
                                  DropdownMenuItem(
                                      value: 'Dark', child: Text('Dark')),
                                  DropdownMenuItem(
                                      value: 'Auto', child: Text('Auto')),
                                ],
                                onChanged: (v) {
                                  if (v != null) {
                                    setState(() => themeMode = v);
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Achievements
                    Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      elevation: 1.5,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.emoji_events, size: 20),
                                const SizedBox(width: 8),
                                Text('Achievements',
                                    style: theme.textTheme.titleMedium
                                        ?.copyWith(fontWeight: FontWeight.w600)),
                                const Spacer(),
                                TextButton(
                                  onPressed: () {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                          content: Text('Open full history (TODO)')),
                                    );
                                  },
                                  child: const Text('View Full History'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: achievements
                                  .map((a) => Chip(
                                avatar: const Icon(Icons.local_florist,
                                    size: 18),
                                label: Text(a['title']!),
                              ))
                                  .toList(),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showActionsSheet,
        icon: const Icon(Icons.more_horiz),
        label: const Text('Actions'),
      ),
    );
  }
}
