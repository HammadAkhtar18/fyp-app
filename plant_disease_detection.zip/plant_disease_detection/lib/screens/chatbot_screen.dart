import 'package:flutter/material.dart';

class ChatBotScreen extends StatefulWidget {
  const ChatBotScreen({super.key});

  @override
  State<ChatBotScreen> createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];

  @override
  void initState() {
    super.initState();
    // Initial Bot Greeting
    _messages.add({
      "sender": "bot",
      "text":
      "👋 Hello, I'm Agronomy that can answer questions related to plants. Please consider my answers as suggestions that need to be checked before followed. How can I help you today?",
    });
  }

  void _sendMessage() {
    if (_controller.text.trim().isEmpty) return;
    setState(() {
      _messages.add({"sender": "user", "text": _controller.text.trim()});
      _controller.clear();

      // Dummy bot reply for now
      Future.delayed(const Duration(milliseconds: 600), () {
        setState(() {
          _messages.add({
            "sender": "bot",
            "text": "This is a sample reply from Agronomy 🌱",
          });
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/bg.jpg"), // same as login/signup
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // 🟢 AppBar Replacement
              Container(
                padding: const EdgeInsets.all(16),
                child: const Text(
                  "AI Plant Doctor Chatbot",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),

              // 💬 Chat Messages
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final msg = _messages[index];
                    final isUser = msg["sender"] == "user";

                    return Align(
                      alignment:
                      isUser ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 6, horizontal: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isUser
                              ? Colors.green.shade700
                              : Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            if (!isUser) ...[
                              const CircleAvatar(
                                radius: 14,
                                backgroundColor: Colors.white,
                                child: Icon(Icons.smart_toy,
                                    size: 18, color: Colors.green),
                              ),
                              const SizedBox(width: 6),
                            ],
                            Flexible(
                              child: Text(
                                msg["text"]!,
                                style: TextStyle(
                                  color:
                                  isUser ? Colors.white : Colors.black87,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            if (isUser) ...[
                              const SizedBox(width: 6),
                              const CircleAvatar(
                                radius: 14,
                                backgroundColor: Colors.white,
                                child: Icon(Icons.person,
                                    size: 18, color: Colors.green),
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              // ✍️ Input Field
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                color: Colors.white.withOpacity(0.9),
                child: Row(
                  children: [
                    // + Button
                    IconButton(
                      icon: const Icon(Icons.add_circle,
                          color: Colors.green, size: 28),
                      onPressed: () {
                        // Handle file upload
                      },
                    ),
                    // Input Field
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        decoration: const InputDecoration(
                          hintText: "Type your message...",
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    // Send Button
                    IconButton(
                      icon: const Icon(Icons.send,
                          color: Colors.green, size: 28),
                      onPressed: _sendMessage,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
