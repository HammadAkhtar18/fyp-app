import 'package:flutter/material.dart';

class ManageUsersScreen extends StatelessWidget {
  const ManageUsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color primaryGreen = Color(0xFF2E7D32);

    return Scaffold(
      appBar: AppBar(title: const Text('Manage Users')),
      body: const Center(
        child: Text(
          'List of registered users will appear here.',
          style: TextStyle(fontSize: 16, color: primaryGreen),
        ),
      ),
    );
  }
}
