import 'package:flutter/material.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  // Example history data
  List<Map<String, dynamic>> history = [
    {
      "name": "Tomato Plant",
      "date": "Aug 28, 2025",
      "image": "assets/tomato.png",
      "disease": "Blight",
      "description": "Brown spots on leaves spreading fast.",
      "recommendation": "Use copper-based fungicide.",
      "expanded": false,
    },
    {
      "name": "Wheat",
      "date": "Aug 20, 2025",
      "image": "assets/wheat.png",
      "disease": "Rust",
      "description": "Yellowish-orange pustules on stems.",
      "recommendation": "Apply resistant wheat varieties.",
      "expanded": false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true, // ✅ lets bg show behind AppBar
      appBar: AppBar(
        backgroundColor: Colors.transparent, // ✅ transparent bar
        elevation: 0,
        title: const Text(
          "History",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black, // ✅ visible on bg
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          // ✅ Full background image
          Positioned.fill(
            child: Image.asset(
              "assets/bg.jpg", // same as login/signup bg
              fit: BoxFit.cover,
            ),
          ),
          // ✅ Foreground content
          SafeArea(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
              itemCount: history.length,
              itemBuilder: (context, index) {
                var item = history[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 6,
                        offset: const Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset(
                            item["image"],
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: Text(
                          item["name"],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        subtitle: Text(item["date"]),
                        trailing: IconButton(
                          icon: Icon(
                            item["expanded"]
                                ? Icons.expand_less
                                : Icons.chevron_right,
                            color: Colors.green.shade700,
                          ),
                          onPressed: () {
                            setState(() {
                              item["expanded"] = !item["expanded"];
                            });
                          },
                        ),
                      ),
                      if (item["expanded"]) ...[
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Disease: ${item["disease"]}",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black)),
                              const SizedBox(height: 4),
                              Text("Description: ${item["description"]}"),
                              const SizedBox(height: 4),
                              Text("Recommendation: ${item["recommendation"]}"),
                            ],
                          ),
                        ),
                      ],
                      Align(
                        alignment: Alignment.bottomRight,
                        child: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            setState(() {
                              history.removeAt(index);
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
