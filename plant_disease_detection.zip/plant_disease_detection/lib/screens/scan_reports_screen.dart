import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ScanReportsScreen extends StatelessWidget {
  const ScanReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Color primaryGreen = const Color(0xFF2E7D32);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Reports'),
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white,
      ),
      backgroundColor: Colors.grey[100],
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('scan_history').orderBy('timestamp', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final scans = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: scans.length,
            itemBuilder: (context, index) {
              final scan = scans[index];
              return Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: const Icon(Icons.image, color: Colors.green),
                  title: Text(scan['plantName'] ?? 'Unknown Plant'),
                  subtitle: Text('Disease: ${scan['disease'] ?? 'Unknown'}'),
                  trailing: Text(
                    (scan['timestamp'] != null)
                        ? DateTime.fromMillisecondsSinceEpoch(scan['timestamp'].millisecondsSinceEpoch)
                        .toString()
                        .split('.')[0]
                        : '',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
