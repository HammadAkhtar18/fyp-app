import 'package:flutter/material.dart';

class ManagePlantsScreen extends StatelessWidget {
  const ManagePlantsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const Color primaryGreen = Color(0xFF2E7D32);

    return Scaffold(
      appBar: AppBar(title: const Text('Manage Plants')),
      body: const Center(
        child: Text(
          'Add, update, or delete plant data here.',
          style: TextStyle(fontSize: 16, color: primaryGreen),
        ),
      ),
    );
  }
}
