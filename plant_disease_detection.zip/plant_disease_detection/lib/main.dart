import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';   // auto generated

// ✅ User Screens
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';
import 'screens/scan_plant_screen.dart';
import 'screens/chatbot_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/edit_profile_screen.dart';

// ✅ Admin Screens
import 'screens/admin_dashboard_screen.dart';
import 'screens/manage_users_screen.dart';
import 'screens/manage_plants_screen.dart';
import 'screens/scan_reports_screen.dart';
import 'screens/admin_settings_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const Color primaryGreen = Color(0xFF2E7D32);

    return MaterialApp(
      title: 'AI Plant Doctor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: primaryGreen,
        colorScheme: ColorScheme.fromSeed(seedColor: primaryGreen),
        scaffoldBackgroundColor: Colors.grey[100],
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: primaryGreen,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 2,
        ),
      ),

      // ✅ Start from SplashScreen
      initialRoute: '/splash',

      routes: {
        // 🌿 User Routes
        '/splash': (context) => const SplashScreen(),
        '/welcome': (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/scan': (context) => const ScanPlantScreen(),
        '/chatbot': (context) => const ChatBotScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/edit_profile': (context) => const EditProfileScreen(),

        // 🌿 Admin Routes
        '/admin': (context) => const AdminDashboardScreen(),
        '/manage_users': (context) => const ManageUsersScreen(),
        '/manage_plants': (context) => const ManagePlantsScreen(),
        '/scan_reports': (context) => const ScanReportsScreen(),
        '/admin_settings': (context) => const AdminSettingsScreen(),
      },

      // ✅ Dynamic routing for /home
      onGenerateRoute: (settings) {
        if (settings.name == '/home') {
          final userName = (settings.arguments as String?) ?? 'User';
          return MaterialPageRoute(
            builder: (_) => HomeScreen(userName: userName),
          );
        }
        return null;
      },
    );
  }
}