package com.example.plant_disease_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
